(function(){
    const cfg = window.FireworksChatbotConfig || {};
  
    function h(tag, attrs={}, ...children){
      const el = document.createElement(tag);
      for (const [k,v] of Object.entries(attrs||{})){
        if (k === 'class') el.className = v;
        else if (k === 'dataset'){ Object.assign(el.dataset, v); }
        else el.setAttribute(k, v);
      }
      for (const c of children){
        if (c == null) continue;
        if (typeof c === 'string') el.appendChild(document.createTextNode(c));
        else el.appendChild(c);
      }
      return el;
    }
  
    function createMessageEl(role, text){
      return h('div', {class: 'fwc-msg ' + (role==='user' ? 'fwc-user' : 'fwc-bot')},
        h('div', {class:'fwc-bubble'}, text)
      );
    }
  
    function render(container){
      const chat = container.querySelector('.fwc-chat');
      const form = container.querySelector('.fwc-input');
      const textarea = form.querySelector('textarea');
  
      const key = 'fwc_session_' + (location.pathname || 'root');
      let history = JSON.parse(sessionStorage.getItem(key) || '[]');
      function sync(){ sessionStorage.setItem(key, JSON.stringify(history.slice(-30))); }
  
      function add(role, content){
        chat.appendChild(createMessageEl(role, content));
        chat.scrollTop = chat.scrollHeight;
      }
  
      history.forEach(m => add(m.role, m.content));
  
      form.addEventListener('submit', async (e)=>{
        e.preventDefault();
        const text = textarea.value.trim();
        if (!text) return;
  
        textarea.value = '';
        add('user', text);
        history.push({role:'user', content:text});
        sync();
  
        const thinking = createMessageEl('assistant', '…');
        thinking.querySelector('.fwc-bubble').classList.add('fwc-thinking');
        chat.appendChild(thinking);
        chat.scrollTop = chat.scrollHeight;
  
        try {
          const res = await fetch(cfg.restUrl, {
            method: 'POST',
            headers: { 'Content-Type':'application/json' },
            body: JSON.stringify({ messages: history })
          });
          const data = await res.json();
          thinking.remove();
  
          if (!res.ok) throw new Error(data.error || ('HTTP ' + res.status));
  
          const reply = (data.reply || '').toString();
          add('assistant', reply);
          history.push({role:'assistant', content:reply});
          sync();
        } catch(err){
          thinking.remove();
          add('assistant', 'Error: ' + err.message);
        }
      });
    }
  
    document.addEventListener('DOMContentLoaded', function(){
      document.querySelectorAll('[data-fwc]').forEach(render);
    });
  })();
  