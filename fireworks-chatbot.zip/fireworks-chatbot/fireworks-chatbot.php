<?php
/**
 * Plugin Name: Dobby Chatbot
 * Description: Drop-in chatbot for your site using Dobby Chat Completions API. Provides a shortcode [Dobby_chatbot] and a REST proxy that keeps your API key server-side.
 * Version: 1.0.0
 * Author: Your Name
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) { exit; }

class Fireworks_Chatbot_Plugin {
    const OPTION_GROUP   = 'fireworks_chatbot_options_group';
    const OPTION_NAME    = 'fireworks_chatbot_options';
    const REST_NAMESPACE = 'fireworks/v1';
    const REST_ROUTE     = '/chat';

    public function __construct() {
        add_action('admin_menu', [$this, 'register_settings_page']);
        add_action('admin_init', [$this, 'register_settings']);

        add_shortcode('fireworks_chatbot', [$this, 'render_chatbot']);
        add_action('wp_enqueue_scripts', [$this, 'register_assets']);

        add_action('rest_api_init', [$this, 'register_rest_routes']);

        register_activation_hook(__FILE__, [__CLASS__, 'on_activate']);
    }

    public static function on_activate() {
        $defaults = [
            'api_key'           => '',
            'api_url'           => 'https://api.fireworks.ai/inference/v1/chat/completions',
            'model'             => 'accounts/fireworks/models/llama-v3p1-70b-instruct',
            'system_prompt'     => "You are a helpful website assistant.",
            'max_tokens'        => 512,
            'temperature'       => 0.7,
            'rate_limit_per_min'=> 20,
        ];
        $existing = get_option(self::OPTION_NAME, []);
        update_option(self::OPTION_NAME, wp_parse_args($existing, $defaults));
    }


    public function register_settings_page() {
        add_options_page(
            'Dobby Chatbot',
            'Dobby Chatbot',
            'manage_options',
            'fireworks-chatbot',
            [$this, 'render_settings_page']
        );
    }

    public function register_settings() {
        register_setting(self::OPTION_GROUP, self::OPTION_NAME, [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize_options'],
            'default' => []
        ]);

        add_settings_section('fw_main', 'API Settings', function() {
            echo '<p>Enter your Fireworks.ai credentials and preferences. Your API key is stored server-side and never exposed to the browser.</p>';
        }, 'fireworks-chatbot');

        add_settings_field('api_key', 'API Key',            [$this, 'field_api_key'],        'fireworks-chatbot', 'fw_main');
        add_settings_field('api_url', 'API URL',            [$this, 'field_api_url'],        'fireworks-chatbot', 'fw_main');
        add_settings_field('model', 'Model ID',             [$this, 'field_model'],          'fireworks-chatbot', 'fw_main');
        add_settings_field('system_prompt', 'System Prompt',[$this, 'field_system_prompt'],  'fireworks-chatbot', 'fw_main');
        add_settings_field('max_tokens', 'Max Tokens',      [$this, 'field_max_tokens'],     'fireworks-chatbot', 'fw_main');
        add_settings_field('temperature', 'Temperature',    [$this, 'field_temperature'],    'fireworks-chatbot', 'fw_main');
        add_settings_field('rate_limit_per_min', 'Rate Limit / minute', [$this, 'field_rate_limit'], 'fireworks-chatbot', 'fw_main');
    }

    public function sanitize_options($opts) {
        $out = [];
        $out['api_key']            = isset($opts['api_key']) ? trim($opts['api_key']) : '';
        $out['api_url']            = isset($opts['api_url']) ? esc_url_raw($opts['api_url']) : '';
        $out['model']              = isset($opts['model']) ? sanitize_text_field($opts['model']) : '';
        $out['system_prompt']      = isset($opts['system_prompt']) ? wp_kses_post($opts['system_prompt']) : '';
        $out['max_tokens']         = isset($opts['max_tokens']) ? max(1, (int)$opts['max_tokens']) : 512;
        $out['temperature']        = isset($opts['temperature']) ? min(2.0, max(0.0, floatval($opts['temperature']))) : 0.7;
        $out['rate_limit_per_min'] = isset($opts['rate_limit_per_min']) ? max(1, (int)$opts['rate_limit_per_min']) : 20;
        return $out;
    }

    public function get_options() {
        $opts = get_option(self::OPTION_NAME, []);
        if (defined('FIREWORKS_API_KEY') && FIREWORKS_API_KEY) { $opts['api_key'] = FIREWORKS_API_KEY; }
        if (defined('FIREWORKS_MODEL')  && FIREWORKS_MODEL)  { $opts['model']  = FIREWORKS_MODEL; }
        if (defined('FIREWORKS_URL')    && FIREWORKS_URL)    { $opts['api_url']= FIREWORKS_URL; }
        return $opts;
    }

    public function field_api_key() {
        $val = $this->get_options()['api_key'] ?? '';
        echo '<input type="password" name="' . self::OPTION_NAME . '[api_key]" value="' . esc_attr($val) . '" class="regular-text" placeholder="fw_..." />';
    }
    public function field_api_url() {
        $val = $this->get_options()['api_url'] ?? '';
        echo '<input type="url" name="' . self::OPTION_NAME . '[api_url]" value="' . esc_attr($val) . '" class="regular-text code" />';
    }
    public function field_model() {
        $val = $this->get_options()['model'] ?? '';
        echo '<input type="text" name="' . self::OPTION_NAME . '[model]" value="' . esc_attr($val) . '" class="regular-text code" />';
        echo '<p class="description">Example: accounts/fireworks/models/llama-v3p1-70b-instruct</p>';
    }
    public function field_system_prompt() {
        $val = $this->get_options()['system_prompt'] ?? '';
        echo '<textarea name="' . self::OPTION_NAME . '[system_prompt]" rows="3" class="large-text">' . esc_textarea($val) . '</textarea>';
    }
    public function field_max_tokens() {
        $val = $this->get_options()['max_tokens'] ?? 512;
        echo '<input type="number" min="1" max="8192" name="' . self::OPTION_NAME . '[max_tokens]" value="' . esc_attr($val) . '" />';
    }
    public function field_temperature() {
        $val = $this->get_options()['temperature'] ?? 0.7;
        echo '<input type="number" step="0.01" min="0" max="2" name="' . self::OPTION_NAME . '[temperature]" value="' . esc_attr($val) . '" />';
    }
    public function field_rate_limit() {
        $val = $this->get_options()['rate_limit_per_min'] ?? 20;
        echo '<input type="number" min="1" max="300" name="' . self::OPTION_NAME . '[rate_limit_per_min]" value="' . esc_attr($val) . '" />';
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) { return; }
        echo '<div class="wrap"><h1>Dobby Chatbot</h1>';
        echo '<form method="post" action="options.php">';
        settings_fields(self::OPTION_GROUP);
        do_settings_sections('fireworks-chatbot');
        submit_button();
        echo '</form>';
        echo '<hr/><p>Use the shortcode <code>[Dobby_chatbot]</code> anywhere to embed the chat UI.</p>';
        echo '</div>';
    }


    public function register_assets() {
        $handle_js  = 'fireworks-chatbot-js';
        $handle_css = 'fireworks-chatbot-css';

        wp_register_script(
            $handle_js,
            plugins_url('assets/js/chatbot.js', __FILE__),
            [],
            '1.0.0',
            true
        );
        wp_register_style(
            $handle_css,
            plugins_url('assets/css/chatbot.css', __FILE__),
            [],
            '1.0.0'
        );

        $public_config = [
            'restUrl'   => esc_url_raw(rest_url(self::REST_NAMESPACE . self::REST_ROUTE)),
            'siteName'  => get_bloginfo('name'),
            'maxUserMessageChars' => 4000,
        ];
        wp_localize_script($handle_js, 'FireworksChatbotConfig', $public_config);
    }

    public function render_chatbot($atts) {
        wp_enqueue_script('fireworks-chatbot-js');
        wp_enqueue_style('fireworks-chatbot-css');

        $atts = shortcode_atts([
            'title'       => 'Ask Dobby Assistant',
            'placeholder' => 'Type your question...'
        ], $atts, 'fireworks_chatbot');

        ob_start(); ?>
        <div class="fwc-container" data-fwc>
            <div class="fwc-header">
                <div class="fwc-title"><?php echo esc_html($atts['title']); ?></div>
                <div class="fwc-sub">Powered by Dobby api</div>
            </div>
            <div class="fwc-chat" aria-live="polite"></div>
            <form class="fwc-input" autocomplete="off">
                <textarea name="message" rows="2" maxlength="4000" placeholder="<?php echo esc_attr($atts['placeholder']); ?>"></textarea>
                <button type="submit" class="fwc-send">Send</button>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }


    public function register_rest_routes() {
        register_rest_route(self::REST_NAMESPACE, self::REST_ROUTE, [
            'methods'             => 'POST',
            'callback'            => [$this, 'handle_chat_request'],
            'permission_callback' => '__return_true', 
            'args'                => [
                'messages' => ['required' => true],
                'meta'     => ['required' => false],
            ],
        ]);
    }

    private function check_rate_limit($limit_per_min) {
        $ip  = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $key = 'fwc_rl_' . md5($ip);
        $data = get_transient($key);
        $now  = time();

        if (!$data) { $data = ['count' => 0, 'start' => $now]; }
        if (($now - $data['start']) >= 60) { $data = ['count' => 0, 'start' => $now]; }
        if ($data['count'] >= $limit_per_min) { return false; }

        $data['count']++;
        set_transient($key, $data, 60);
        return true;
    }

    public function handle_chat_request(\WP_REST_Request $request) {
        $opts = $this->get_options();
        if (empty($opts['api_key'])) {
            return new \WP_REST_Response(['error' => 'Server is not configured. Missing API key.'], 500);
        }
        if (!$this->check_rate_limit((int)$opts['rate_limit_per_min'])) {
            return new \WP_REST_Response(['error' => 'Rate limit exceeded. Try again in a minute.'], 429);
        }

        $payload  = $request->get_json_params();
        $messages = isset($payload['messages']) ? $payload['messages'] : [];
        if (!is_array($messages) || empty($messages)) {
            return new \WP_REST_Response(['error' => 'Invalid messages format.'], 400);
        }

        $clean_messages = [];
        $total_chars = 0;
        foreach ($messages as $m) {
            $role    = isset($m['role']) ? sanitize_text_field($m['role']) : '';
            $content = isset($m['content']) ? wp_strip_all_tags((string)$m['content']) : '';
            if (!$role || $content === '') continue;
            $total_chars += strlen($content);
            $clean_messages[] = ['role' => $role, 'content' => mb_substr($content, 0, 8000)];
        }
        if (empty($clean_messages)) {
            return new \WP_REST_Response(['error' => 'No messages after sanitization.'], 400);
        }
        if ($total_chars > 40000) {
            return new \WP_REST_Response(['error' => 'Conversation too long. Please start a new chat.'], 400);
        }

        array_unshift($clean_messages, [
            'role' => 'system',
            'content' => $opts['system_prompt'] ?: 'You are a helpful website assistant.',
        ]);

        $body = [
            'model'       => $opts['model'],
            'messages'    => $clean_messages,
            'temperature' => (float)$opts['temperature'],
            'max_tokens'  => (int)$opts['max_tokens'],
        ];

        $args = [
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $opts['api_key'],
            ],
            'body'    => wp_json_encode($body),
            'timeout' => 60,
        ];

        $response = wp_remote_post($opts['api_url'], $args);
        if (is_wp_error($response)) {
            return new \WP_REST_Response(['error' => $response->get_error_message()], 500);
        }

        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if ($code >= 400) {
            $msg = $data['error']['message'] ?? ('Upstream error (' . $code . ')');
            return new \WP_REST_Response(['error' => $msg], $code);
        }

        $reply = '';
        if (isset($data['choices'][0]['message']['content'])) {
            $reply = (string)$data['choices'][0]['message']['content'];
        } elseif (isset($data['choices'][0]['text'])) {
            $reply = (string)$data['choices'][0]['text'];
        }

        return new \WP_REST_Response([
            'reply' => $reply,
            'usage' => $data['usage'] ?? null,
            'model' => $data['model'] ?? $opts['model'],
        ], 200);
    }
}

new Fireworks_Chatbot_Plugin();
